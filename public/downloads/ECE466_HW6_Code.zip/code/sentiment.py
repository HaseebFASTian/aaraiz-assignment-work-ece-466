"""HW6 Q1: RNN/LSTM sentiment classification using the course notebook's data.

No course hyperparameters or IMDB results are assumed here. Supply model
parameters, loaders, optimizer, loss and epoch count from the original notebook.
A batch adapter returns (token_ids, labels, lengths_or_None) without changing
the notebook's vocabulary, tokenization, truncation, labels or data split.
Lengths, if supplied, describe RIGHT-padded sequences; they are never guessed.
"""

import json
import random
from pathlib import Path

import torch
from torch import nn
from torch.nn.utils.rnn import pack_padded_sequence


class SentimentClassifier(nn.Module):
    """Trainable embedding -> final recurrent state -> raw class logits.

    output_mode='binary' requires output_dim=1 and BCEWithLogitsLoss or BCELoss.
    BCELoss receives sigmoid(logits) in the training/evaluation loss path only.
    output_mode='multiclass' uses output_dim classes and CrossEntropyLoss;
    output_dim=2 is also suitable for binary IMDB classification.
    rnn_nonlinearity is used only by RNN, not by LSTM's fixed gate equations.
    Recurrent dropout applies between layers, so it has no effect for one layer.
    """

    def __init__(self, *, vocab_size, embedding_dim, hidden_dim, num_layers,
                 dropout, padding_idx, batch_first, architecture, bidirectional,
                 output_mode, output_dim, rnn_nonlinearity):
        super().__init__()
        architecture = architecture.upper()
        if architecture not in {"RNN", "LSTM"}:
            raise ValueError("architecture must be RNN or LSTM")
        if output_mode not in {"binary", "multiclass"}:
            raise ValueError("output_mode must be binary or multiclass")
        if (output_mode == "binary" and output_dim != 1) or (
                output_mode == "multiclass" and output_dim < 2):
            raise ValueError("binary needs one logit; multiclass needs >=2 logits")
        self.architecture = architecture
        self.batch_first = batch_first
        self.bidirectional = bidirectional
        self.output_mode = output_mode
        self.embedding = nn.Embedding(vocab_size, embedding_dim,
                                      padding_idx=padding_idx)
        recurrent_args = dict(input_size=embedding_dim, hidden_size=hidden_dim,
                              num_layers=num_layers, dropout=dropout,
                              batch_first=batch_first,
                              bidirectional=bidirectional)
        if architecture == "RNN":
            self.recurrent = nn.RNN(**recurrent_args,
                                    nonlinearity=rnn_nonlinearity)
        else:
            self.recurrent = nn.LSTM(**recurrent_args)
        directions = 2 if bidirectional else 1
        self.classifier = nn.Linear(hidden_dim * directions, output_dim)

    def forward(self, tokens, lengths=None):
        """Return (batch, output_dim); do not apply sigmoid or softmax here."""
        if tokens.ndim != 2:
            raise ValueError("tokens must have batch and sequence dimensions")
        batch_dim, time_dim = (0, 1) if self.batch_first else (1, 0)
        if tokens.shape[batch_dim] == 0 or tokens.shape[time_dim] == 0:
            raise ValueError("empty batches/sequences are not supported")
        embedded = self.embedding(tokens)
        if lengths is not None:
            lengths = torch.as_tensor(lengths).detach().cpu()
            if (lengths.ndim != 1 or len(lengths) != tokens.shape[batch_dim]
                    or lengths.is_floating_point() or lengths.is_complex()
                    or lengths.dtype == torch.bool
                    or torch.any(lengths <= 0)
                    or torch.any(lengths > tokens.shape[time_dim])):
                raise ValueError("lengths must be one valid positive integer per sample")
            embedded = pack_padded_sequence(
                embedded, lengths.to(torch.long), batch_first=self.batch_first,
                enforce_sorted=False)
        _, state = self.recurrent(embedded)
        # LSTM returns (h_n, c_n); a simple RNN returns h_n directly.
        hidden = state[0] if self.architecture == "LSTM" else state
        # h_n layout: (layers * directions, batch, hidden_dim), in both layouts.
        if self.bidirectional:
            final_state = torch.cat((hidden[-2], hidden[-1]), dim=1)
        else:
            final_state = hidden[-1]
        return self.classifier(final_state)


def tuple_batch_adapter(batch):
    """For loaders yielding (tokens, labels[, lengths]); customize if necessary."""
    if len(batch) == 2:
        tokens, labels = batch
        return tokens, labels, None
    if len(batch) == 3:
        return batch
    raise ValueError("expected (tokens, labels) or (tokens, labels, lengths)")


def _targets_and_predictions(model, logits, labels, criterion):
    """Match target shape/type to the caller's loss without changing label IDs."""
    labels = labels.reshape(-1)
    if labels.numel() != logits.shape[0]:
        raise ValueError("one label is required for every review")
    if model.output_mode == "binary":
        if not isinstance(criterion, (nn.BCEWithLogitsLoss, nn.BCELoss)):
            raise TypeError("binary output requires BCEWithLogitsLoss or BCELoss")
        if not torch.all((labels == 0) | (labels == 1)):
            raise ValueError("binary targets must be 0 or 1")
        targets = labels.to(logits.dtype).reshape_as(logits)
        predicted = (logits[:, 0] >= 0).long()  # sigmoid(logit) >= 0.5
        normalizer = targets.numel()
    else:
        if not isinstance(criterion, nn.CrossEntropyLoss):
            raise TypeError("multiclass logits require nn.CrossEntropyLoss")
        if (labels.is_floating_point() or labels.is_complex()
                or torch.any(labels < 0) or torch.any(labels >= logits.shape[1])):
            raise ValueError("class targets must be integer IDs in [0, classes)")
        if torch.any(labels == criterion.ignore_index):
            raise ValueError("every review needs a target; ignored labels are unsupported")
        targets = labels.long()
        predicted = logits.argmax(dim=1)
        # CrossEntropy's weighted mean divides by the sum of target weights.
        normalizer = (targets.numel() if criterion.weight is None
                      else criterion.weight[targets].sum().item())
    if normalizer <= 0:
        raise ValueError("the batch loss must have positive total target weight")
    return targets, predicted, normalizer


def _run_epoch(model, loader, criterion, batch_adapter, device,
               optimizer=None, gradient_clip_norm=None):
    training = optimizer is not None
    if training:
        model_ids = {id(parameter) for parameter in model.parameters()}
        trainable_ids = {id(parameter) for parameter in model.parameters()
                         if parameter.requires_grad}
        optimizer_ids = {id(parameter) for group in optimizer.param_groups
                         for parameter in group["params"]}
        if not trainable_ids <= optimizer_ids or not optimizer_ids <= model_ids:
            raise ValueError("optimizer must cover this model's trainable parameters only")
    if criterion.reduction not in {"mean", "sum"}:
        raise ValueError("use the notebook's mean or sum loss reduction")
    if gradient_clip_norm is not None and gradient_clip_norm <= 0:
        raise ValueError("gradient_clip_norm must be positive or None")
    model.train(training)
    criterion = criterion.to(device)
    loss_total = denominator = correct = examples = 0
    with torch.set_grad_enabled(training):
        for batch in loader:
            tokens, labels, lengths = batch_adapter(batch)
            tokens, labels = tokens.to(device), labels.to(device)
            if training:
                optimizer.zero_grad(set_to_none=True)
            logits = model(tokens, lengths)
            targets, predicted, weight = _targets_and_predictions(
                model, logits, labels, criterion)
            # Preserve BCELoss if the notebook supplies it; never sigmoid twice.
            loss_input = logits.sigmoid() if isinstance(criterion, nn.BCELoss) else logits
            loss = criterion(loss_input, targets)
            if not torch.isfinite(loss):
                raise FloatingPointError("non-finite loss; inspect data and settings")
            if training:
                loss.backward()
                if gradient_clip_norm is not None:
                    nn.utils.clip_grad_norm_(model.parameters(), gradient_clip_norm)
                optimizer.step()
            loss_total += loss.item() * (weight if criterion.reduction == "mean" else 1)
            denominator += weight
            correct += (predicted == labels.reshape(-1).long()).sum().item()
            examples += labels.numel()
    if examples == 0:
        raise ValueError("loader produced no samples")
    # Loss is normalized across the epoch; accuracy is a fraction in [0, 1].
    return {"loss": loss_total / denominator, "accuracy": correct / examples,
            "correct": correct, "examples": examples}


def train_epoch(model, loader, *, criterion, optimizer, batch_adapter, device,
                gradient_clip_norm):
    """One pass over the supplied training loader, preserving its sampling."""
    return _run_epoch(model, loader, criterion, batch_adapter, device,
                      optimizer, gradient_clip_norm)


def evaluate(model, loader, *, criterion, batch_adapter, device):
    """Evaluate with dropout disabled and gradients off; no optimizer updates."""
    return _run_epoch(model, loader, criterion, batch_adapter, device)


def run_experiments(*, model_parameters, loader_factory, optimizer_factory,
                    criterion_factory, batch_adapter, epochs, device, seed,
                    gradient_clip_norm, output_dir, data_description,
                    bonus_configuration=None):
    """Run Q1a's four models and optionally Q1's embedding-size-100 bonus.

    model_parameters contains every constructor parameter except architecture
    and bidirectional, copied from the course notebook. No values are filled in.
    loader_factory(seed) returns NEW (train_loader, test_loader) with the same
    original split/transforms. It should also seed any NumPy/worker generators.
    optimizer_factory(parameters) must create a NEW optimizer bound to those
    parameters; criterion_factory() supplies the notebook's loss function.
    bonus_configuration is None or ("RNN"/"LSTM", bidirectional_bool); all other
    settings match that corresponding Q1a run except embedding_dim becomes 100.
    Metrics/checkpoints are written only after real training and evaluation.
    """
    if not isinstance(epochs, int) or epochs < 1:
        raise ValueError("epochs must be the positive epoch count from the notebook")
    if not data_description.strip():
        raise ValueError("identify the actual data/split used in data_description")
    if {"architecture", "bidirectional"} & model_parameters.keys():
        raise ValueError("the driver sets architecture and bidirectional")
    runs = [(arch, bidir, None) for arch in ("RNN", "LSTM")
            for bidir in (False, True)]
    if bonus_configuration is not None:
        arch, bidir = bonus_configuration
        if arch.upper() not in {"RNN", "LSTM"} or not isinstance(bidir, bool):
            raise ValueError("bonus_configuration must be (RNN/LSTM, bool)")
        runs.append((arch.upper(), bidir, 100))
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    results = {}
    for architecture, bidirectional, bonus_dim in runs:
        random.seed(seed)
        torch.manual_seed(seed)
        parameters = dict(model_parameters, architecture=architecture,
                          bidirectional=bidirectional)
        if bonus_dim is not None:
            parameters["embedding_dim"] = bonus_dim
        name = f"{architecture.lower()}_{'bi' if bidirectional else 'uni'}"
        if bonus_dim is not None:
            name += "_embedding100"
        model = SentimentClassifier(**parameters).to(device)
        optimizer = optimizer_factory(model.parameters())
        criterion = criterion_factory().to(device)
        train_loader, test_loader = loader_factory(seed)
        history = []
        for epoch in range(1, epochs + 1):
            metrics = train_epoch(
                model, train_loader, criterion=criterion, optimizer=optimizer,
                batch_adapter=batch_adapter, device=device,
                gradient_clip_norm=gradient_clip_norm)
            history.append({"epoch": epoch, **metrics})
        test_metrics = evaluate(model, test_loader, criterion=criterion,
                                batch_adapter=batch_adapter, device=device)
        result = {"model_parameters": parameters, "seed": seed, "epochs": epochs,
                  "data_description": data_description, "device": str(device),
                  "torch_version": str(torch.__version__),
                  "optimizer": type(optimizer).__name__,
                  "criterion": type(criterion).__name__,
                  "loss_reduction": criterion.reduction,
                  "gradient_clip_norm": gradient_clip_norm,
                  "training": history, "test": test_metrics}
        torch.save({"model_state_dict": model.state_dict(),
                    "optimizer_state_dict": optimizer.state_dict(),
                    "criterion_state_dict": criterion.state_dict(),
                    "result": result}, output_dir / f"{name}.pt")
        (output_dir / f"{name}.json").write_text(
            json.dumps(result, indent=2, allow_nan=False), encoding="utf-8")
        results[name] = result
    return results
