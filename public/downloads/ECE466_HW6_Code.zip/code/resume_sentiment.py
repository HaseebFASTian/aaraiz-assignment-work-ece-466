"""Resume a course sentiment model strictly from a completed epoch checkpoint.

Writes a separate candidate run. Never overwrites the original run or changes
floating-point flushing, thread counts, precision or numerical backend settings.
Example: python code/resume_sentiment.py --prepared-dir prepared/sentiment
 --checkpoint results/denormals_benchmark/checkpoint_input.pt
 --output-dir results/sentiment/rnn_uni_resume --configuration rnn_uni
"""

import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
import shutil
import time

import numpy as np
import torch
from torch import nn

from sentiment import SentimentClassifier, _targets_and_predictions, evaluate, tuple_batch_adapter
from run_sentiment import (BATCH_SIZE, CONFIGURATIONS, EPOCHS, HIDDEN_SIZE,
                           LEARNING_RATE, CourseBatches)


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def save_json(path, value):
    temporary = Path(str(path) + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False), encoding="utf-8")
    temporary.replace(path)


def restore_epoch_boundary(checkpoint, features, labels):
    """Restore model, Adam, history and the next permutation without new updates."""
    completed = checkpoint["completed_epochs"]
    if not isinstance(completed, int) or not 1 <= completed <= EPOCHS:
        raise ValueError("checkpoint must record a completed epoch between 1 and 20")
    history = copy.deepcopy(checkpoint["training"])
    if len(history) != completed:
        raise ValueError("checkpoint history does not match completed_epochs")
    for epoch, row in enumerate(history, start=1):
        if row.get("epoch") != epoch or row.get("examples") != len(labels):
            raise ValueError("history must contain contiguous complete epochs")
        if not math.isfinite(row["loss"]) or not 0 <= row["accuracy"] <= 1:
            raise ValueError("invalid saved training metrics")
        if row["correct"] < 0 or row["correct"] > len(labels):
            raise ValueError("invalid saved correct-prediction count")
        if not math.isclose(row["accuracy"], row["correct"] / len(labels), abs_tol=1e-12):
            raise ValueError("saved accuracy and counts disagree")
    parameters = checkpoint["model_parameters"]
    if parameters["dropout"] != 0:
        raise ValueError("this RNG-free replay requires dropout=0")
    model = SentimentClassifier(**parameters)
    model.load_state_dict(checkpoint["model_state_dict"], strict=True)
    for value in model.state_dict().values():
        if value.dtype != torch.float32 or not bool(torch.isfinite(value).all()):
            raise ValueError("checkpoint must contain finite float32 model tensors")
    optimizer = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE)
    optimizer.load_state_dict(copy.deepcopy(checkpoint["optimizer_state_dict"]))
    if len(optimizer.param_groups) != 1:
        raise ValueError("course Adam uses one parameter group")
    group = optimizer.param_groups[0]
    required = {"lr": LEARNING_RATE, "betas": (0.9, 0.999), "eps": 1e-8,
                "weight_decay": 0, "amsgrad": False}
    if any(group.get(key) != value for key, value in required.items()):
        raise ValueError("saved optimizer differs from the course Adam settings")
    expected_steps = completed * math.ceil(len(labels) / BATCH_SIZE)
    if len(optimizer.state) != len(list(model.parameters())):
        raise ValueError("Adam state is missing model parameters")
    for state in optimizer.state.values():
        if int(state["step"].item()) != expected_steps:
            raise ValueError("Adam step count does not match completed full epochs")
        for value in state.values():
            if torch.is_tensor(value) and not bool(torch.isfinite(value).all()):
                raise ValueError("non-finite saved Adam state")
    loader = CourseBatches(features, labels, shuffle=True, seed=checkpoint["seed"])
    for _ in range(completed):
        loader.rng.shuffle(loader.indices)
    return model, optimizer, loader, history


def train_epoch_with_progress(model, loader, optimizer, criterion, epoch, progress_path=None):
    """Original update order, with observations after completed optimizer steps."""
    model.train()
    loss_total = denominator = correct = examples = 0
    epoch_started = time.perf_counter()
    for batch_number, batch in enumerate(loader, start=1):
        batch_started = time.perf_counter()
        tokens, labels, lengths = tuple_batch_adapter(batch)
        optimizer.zero_grad(set_to_none=True)
        start = time.perf_counter()
        logits = model(tokens, lengths)
        targets, predicted, weight = _targets_and_predictions(model, logits, labels, criterion)
        loss = criterion(logits, targets)
        forward_seconds = time.perf_counter() - start
        if not torch.isfinite(loss):
            raise FloatingPointError("non-finite resumed loss")
        start = time.perf_counter()
        loss.backward()
        backward_seconds = time.perf_counter() - start
        start = time.perf_counter()
        optimizer.step()
        adam_seconds = time.perf_counter() - start
        loss_total += loss.item() * weight
        denominator += weight
        correct += (predicted == labels.reshape(-1).long()).sum().item()
        examples += labels.numel()
        batch_seconds = time.perf_counter() - batch_started
        if progress_path is not None and (batch_number == 1 or batch_number % 50 == 0
                                          or batch_number == len(loader) or batch_seconds > 2):
            progress = {"state": "partial_epoch", "epoch": epoch,
                        "completed_batches": batch_number, "total_batches": len(loader),
                        "seen_examples": examples, "total_examples": len(loader.labels),
                        "online_loss": loss_total / denominator, "online_accuracy": correct / examples,
                        "elapsed_seconds": time.perf_counter() - epoch_started,
                        "last_batch_seconds": batch_seconds, "slow_batch": batch_seconds > 2,
                        "forward_seconds": forward_seconds, "backward_seconds": backward_seconds,
                        "adam_seconds": adam_seconds}
            save_json(progress_path, progress)
            print(json.dumps(progress), flush=True)
    if examples != len(loader.labels):
        raise ValueError("resumed epoch did not cover every training example")
    result = {"loss": loss_total / denominator, "accuracy": correct / examples,
              "correct": correct, "examples": examples}
    if progress_path is not None:
        progress.update(state="epoch_complete", elapsed_seconds=time.perf_counter() - epoch_started)
        save_json(progress_path, progress)
    return result


def resume(args):
    if torch.get_num_threads() != args.expected_threads:
        raise ValueError(f"expected {args.expected_threads} CPU threads; observed {torch.get_num_threads()}; set the job environment to match the original run")
    metadata = json.loads((args.prepared_dir / "metadata.json").read_text(encoding="utf-8"))
    data_path = args.prepared_dir / "data.npz"
    data_hash = sha256(data_path)
    if data_hash != metadata["data_sha256"] or sha256(args.prepared_dir / "tokenizer.json") != metadata["tokenizer_sha256"]:
        raise ValueError("prepared data or tokenizer hash mismatch")
    if not metadata["full_course_dataset"] or metadata["train_examples"] != 45000 or metadata["test_examples"] != 5000:
        raise ValueError("the candidate requires the complete prepared course split")
    if args.output_dir.exists() and any(args.output_dir.iterdir()):
        raise FileExistsError("candidate output directory must be new or empty")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    captured = args.output_dir / "source_checkpoint.pt"
    shutil.copy2(args.checkpoint, captured)
    checkpoint_hash = sha256(captured)
    if args.checkpoint_sha256 and checkpoint_hash.lower() != args.checkpoint_sha256.lower():
        raise ValueError("captured checkpoint differs from the expected SHA-256")
    checkpoint = torch.load(captured, map_location="cpu", weights_only=True)
    if checkpoint["data_sha256"] != data_hash or checkpoint["seed"] != metadata["seed"]:
        raise ValueError("checkpoint data hash/seed does not match prepared data")
    if args.expected_epoch is not None and checkpoint["completed_epochs"] != args.expected_epoch:
        raise ValueError("checkpoint is not from the expected completed epoch")
    architecture, bidirectional, embedding_dim = CONFIGURATIONS[args.configuration]
    expected = dict(vocab_size=metadata["embedding_rows"], embedding_dim=embedding_dim,
                    hidden_dim=HIDDEN_SIZE, num_layers=1, dropout=0.0, padding_idx=0,
                    batch_first=True, architecture=architecture, bidirectional=bidirectional,
                    output_mode="multiclass", output_dim=2, rnn_nonlinearity="tanh")
    if checkpoint["model_parameters"] != expected:
        raise ValueError("checkpoint architecture/configuration differs from the course run")
    with np.load(data_path, allow_pickle=False) as arrays:
        features, labels = arrays["x_train"], arrays["y_train"]
        if features.shape != (45000, 80) or labels.shape != (45000,):
            raise ValueError("unexpected training array shape")
        model, optimizer, loader, history = restore_epoch_boundary(checkpoint, features, labels)
        test_loader = CourseBatches(arrays["x_test"], arrays["y_test"], shuffle=False,
                                    seed=checkpoint["seed"])
    provenance = {"method": "strict epoch-boundary continuation",
                  "source_checkpoint": str(args.checkpoint.resolve()),
                  "source_checkpoint_sha256": checkpoint_hash,
                  "resumed_from_completed_epoch": checkpoint["completed_epochs"],
                  "sampler_completed_shuffles_replayed": checkpoint["completed_epochs"],
                  "cpu_threads": torch.get_num_threads(),
                  "interop_threads": torch.get_num_interop_threads(),
                  "flush_denormal_modified": False, "precision_or_backend_modified": False,
                  "original_run_untouched": True}
    save_json(args.output_dir / "resume_provenance.json", provenance)
    save_json(args.output_dir / "training_history.json", history)
    criterion = nn.CrossEntropyLoss()
    started = time.perf_counter()
    print(json.dumps({"configuration": args.configuration, "resume": provenance}), flush=True)
    for epoch in range(checkpoint["completed_epochs"] + 1, EPOCHS + 1):
        epoch_started = time.perf_counter()
        metrics = train_epoch_with_progress(model, loader, optimizer, criterion, epoch,
                                            args.output_dir / "training_progress.json")
        history.append({"epoch": epoch, **metrics, "seconds": time.perf_counter() - epoch_started})
        save_json(args.output_dir / "training_history.json", history)
        print(json.dumps(history[-1]), flush=True)
        if epoch % 5 == 0 or epoch == EPOCHS:
            temporary = args.output_dir / "model.pt.tmp"
            torch.save({"model_state_dict": model.state_dict(),
                        "optimizer_state_dict": optimizer.state_dict(),
                        "model_parameters": expected, "completed_epochs": epoch,
                        "training": history, "seed": checkpoint["seed"],
                        "data_sha256": data_hash, "resume": provenance}, temporary)
            temporary.replace(args.output_dir / "model.pt")
    if checkpoint["completed_epochs"] == EPOCHS:
        shutil.copy2(captured, args.output_dir / "model.pt")
    test = evaluate(model, test_loader, criterion=criterion, batch_adapter=tuple_batch_adapter,
                    device="cpu")
    resumed_seconds = time.perf_counter() - started
    prior_seconds = sum(row.get("seconds", 0) for row in checkpoint["training"])
    result = {"configuration": args.configuration, "model_parameters": expected,
              "epochs": EPOCHS, "batch_size": BATCH_SIZE, "optimizer": "Adam",
              "learning_rate": LEARNING_RATE, "criterion": "CrossEntropyLoss",
              "gradient_clip_norm": None, "seed": checkpoint["seed"], "device": "cpu",
              "torch_version": str(torch.__version__), "prepared_data": metadata,
              "training": history, "test": test, "elapsed_seconds": prior_seconds + resumed_seconds,
              "elapsed_seconds_definition": "saved prior epoch times plus resumed wall time; excludes discarded partial work and downtime",
              "resumed_elapsed_seconds": resumed_seconds, "resume": provenance}
    save_json(args.output_dir / "metrics.json", result)
    print(json.dumps({"configuration": args.configuration, "test": test}), flush=True)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prepared-dir", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--configuration", choices=CONFIGURATIONS, default="rnn_uni")
    parser.add_argument("--checkpoint-sha256")
    parser.add_argument("--expected-epoch", type=int)
    parser.add_argument("--expected-threads", type=int, default=4)
    resume(parser.parse_args())
