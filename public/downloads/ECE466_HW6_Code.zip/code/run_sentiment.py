"""Run HW6 Q1 with the supplied sentiment-analysis-task.ipynb settings.

Prepare the course's pooled 90/10 split ONCE, then share that cache between jobs:
  python run_sentiment.py prepare --dataset-root /path/to/aclImdb --prepared-dir prepared
  python run_sentiment.py train --prepared-dir prepared --output-dir results --configuration rnn_uni
  python run_sentiment.py all --prepared-dir prepared --output-dir results

The original notebook pools the official train/test folders and makes a new
45,000/5,000 split. Report this course split, not official IMDB test performance.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path
import random
import re
import string
import time

# Keras is needed only for its original tokenizer/padding, not for training.
os.environ.setdefault("KERAS_BACKEND", "torch")
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")

import numpy as np
import torch
from torch import nn

from sentiment import SentimentClassifier, evaluate, train_epoch, tuple_batch_adapter


SEED = 466  # Added for reproducibility; the notebook does not specify a seed.
EPOCHS, BATCH_SIZE, HIDDEN_SIZE, LEARNING_RATE = 20, 64, 164, 0.0001
BASE_EMBEDDING, MAX_WORDS, MAX_LENGTH = 10, 10000, 80
CONFIGURATIONS = {
    "rnn_uni": ("RNN", False, 10),
    "rnn_bi": ("RNN", True, 10),
    "lstm_uni": ("LSTM", False, 10),
    "lstm_bi": ("LSTM", True, 10),
    "lstm_bi_embedding100": ("LSTM", True, 100),
}


def custom_standardization(text):
    """Exactly the notebook's lowercasing, <br /> removal and punctuation deletion."""
    lowercase = text.lower()
    stripped_html = re.sub("<br />", " ", lowercase)
    return re.sub("[%s]" % re.escape(string.punctuation), "", stripped_html)


def _save_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False), encoding="utf-8")
    temporary.replace(path)


def _sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as file:
        for block in iter(lambda: file.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def prepare_course_data(dataset_root, prepared_dir, *, seed=SEED,
                        require_full_dataset=True):
    """Persist the original transformation; train/test never refit it per model.

    require_full_dataset=False exists only for small unit-test fixtures.
    No unsupervised reviews are included. Files are sorted for reproducibility.
    """
    import pandas as pd
    import sklearn
    import keras
    from sklearn.model_selection import train_test_split
    from keras.src.legacy.preprocessing.text import Tokenizer
    from keras.utils import pad_sequences

    dataset_root, prepared_dir = Path(dataset_root), Path(prepared_dir)
    metadata_path = prepared_dir / "metadata.json"
    if metadata_path.exists():
        raise FileExistsError("prepared cache already exists; reuse it or choose a new folder")
    rows, counts = [], {}
    source_digest = hashlib.sha256()
    # Same initial class/folder order as the notebook's concatenated datasets.
    for sentiment, label in (("pos", 1), ("neg", 0)):
        for original_split in ("train", "test"):
            folder = dataset_root / original_split / sentiment
            files = sorted(folder.glob("*.txt"))
            counts[f"{original_split}/{sentiment}"] = len(files)
            if not files or (require_full_dataset and len(files) != 12500):
                raise ValueError(f"expected {'12500' if require_full_dataset else 'some'} reviews in {folder}; found {len(files)}")
            for path in files:
                raw = path.read_bytes()
                review_id = path.relative_to(dataset_root).as_posix()
                source_digest.update(review_id.encode("utf-8") + b"\0" + raw + b"\0")
                rows.append((custom_standardization(raw.decode("utf-8")), label, review_id))
    dataset = pd.DataFrame(rows, columns=["Review", "Ratings", "review_id"])
    # A shared local RandomState reproduces the notebook's sample-then-split
    # sequence without depending on unrelated code's global NumPy random state.
    split_rng = np.random.RandomState(seed)
    dataset = dataset.sample(frac=1, random_state=split_rng).reset_index(drop=True)
    train_indices, test_indices = train_test_split(
        np.arange(len(dataset)), test_size=0.1, stratify=dataset["Ratings"],
        random_state=split_rng)
    training, testing = dataset.iloc[train_indices], dataset.iloc[test_indices]
    tokenizer = Tokenizer(num_words=MAX_WORDS, oov_token="<OOV>")
    tokenizer.fit_on_texts(training["Review"])
    x_train = pad_sequences(tokenizer.texts_to_sequences(training["Review"]),
                            maxlen=MAX_LENGTH, padding="pre", truncating="pre")
    x_test = pad_sequences(tokenizer.texts_to_sequences(testing["Review"]),
                           maxlen=MAX_LENGTH, padding="pre", truncating="pre")
    total_word = len(tokenizer.word_index)
    # The full IMDB vocabulary exceeds 10,000, so this matches total_word.
    # A small fixture needs +1 if its highest one-based token ID equals its size.
    max_token_id = max(int(x_train.max()), int(x_test.max()))
    embedding_rows = max(total_word, max_token_id + 1)
    arrays = dict(x_train=x_train, x_test=x_test,
                  y_train=training["Ratings"].to_numpy(dtype=np.int64),
                  y_test=testing["Ratings"].to_numpy(dtype=np.int64),
                  train_ids=training["review_id"].to_numpy(dtype=str),
                  test_ids=testing["review_id"].to_numpy(dtype=str))
    prepared_dir.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(prepared_dir / "data.npz", **arrays)
    (prepared_dir / "tokenizer.json").write_text(tokenizer.to_json(), encoding="utf-8")
    metadata = {
        "seed": seed, "source_root": str(dataset_root.resolve()),
        "source_counts": counts, "source_sha256": source_digest.hexdigest(),
        "split": "pool official train+test, then stratified 90/10 course split",
        "train_examples": len(training), "test_examples": len(testing),
        "train_label_counts": np.bincount(arrays["y_train"], minlength=2).tolist(),
        "test_label_counts": np.bincount(arrays["y_test"], minlength=2).tolist(),
        "tokenizer_num_words": MAX_WORDS, "oov_token": "<OOV>",
        "total_word": total_word, "embedding_rows": embedding_rows,
        "max_token_id": max_token_id, "sequence_length": MAX_LENGTH,
        "padding": "pre", "truncating": "pre", "padding_index": 0,
        "full_course_dataset": require_full_dataset,
        "preprocessing_versions": {"numpy": np.__version__, "pandas": pd.__version__,
                                   "scikit_learn": sklearn.__version__,
                                   "keras": keras.__version__},
        "data_sha256": _sha256(prepared_dir / "data.npz"),
        "tokenizer_sha256": _sha256(prepared_dir / "tokenizer.json"),
    }
    _save_json(metadata_path, metadata)  # Written last: marks the cache complete.
    return metadata


class CourseBatches:
    """The notebook's in-place NumPy permutation and complete 64-sample batches."""

    def __init__(self, features, labels, *, shuffle, seed, batch_size=BATCH_SIZE):
        self.features = torch.as_tensor(features, dtype=torch.long)
        self.labels = torch.as_tensor(labels, dtype=torch.long)
        self.indices = np.arange(len(labels))
        self.rng = np.random.RandomState(seed)
        self.shuffle = shuffle
        self.batch_size = batch_size

    def __len__(self):
        return (len(self.indices) + self.batch_size - 1) // self.batch_size

    def __iter__(self):
        if self.shuffle:
            self.rng.shuffle(self.indices)
        for start in range(0, len(self.indices), self.batch_size):
            indices = self.indices[start:start + self.batch_size]
            # No lengths/packing: original pre-padding is intentionally retained.
            yield self.features[indices], self.labels[indices], None


def train_configuration(prepared_dir, output_dir, configuration, *, device="cuda"):
    """Train the specified configuration for exactly the notebook's 20 epochs."""
    prepared_dir = Path(prepared_dir)
    metadata = json.loads((prepared_dir / "metadata.json").read_text(encoding="utf-8"))
    if _sha256(prepared_dir / "data.npz") != metadata["data_sha256"]:
        raise ValueError("prepared arrays changed after preparation")
    if _sha256(prepared_dir / "tokenizer.json") != metadata["tokenizer_sha256"]:
        raise ValueError("prepared vocabulary changed after preparation")
    if not metadata["full_course_dataset"]:
        raise ValueError("course training requires the complete 50,000-review dataset")
    if str(device).startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable; select an available GPU or --device cpu")
    seed = metadata["seed"]
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    architecture, bidirectional, embedding_dim = CONFIGURATIONS[configuration]
    parameters = dict(vocab_size=metadata["embedding_rows"], embedding_dim=embedding_dim,
                      hidden_dim=HIDDEN_SIZE, num_layers=1, dropout=0.0,
                      padding_idx=0, batch_first=True, architecture=architecture,
                      bidirectional=bidirectional, output_mode="multiclass",
                      output_dim=2, rnn_nonlinearity="tanh")
    model = SentimentClassifier(**parameters).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE)
    criterion = nn.CrossEntropyLoss()
    with np.load(prepared_dir / "data.npz", allow_pickle=False) as arrays:
        train_loader = CourseBatches(arrays["x_train"], arrays["y_train"],
                                     shuffle=True, seed=seed)
        test_loader = CourseBatches(arrays["x_test"], arrays["y_test"],
                                    shuffle=False, seed=seed)
    run_dir = Path(output_dir) / configuration
    run_dir.mkdir(parents=True, exist_ok=True)
    if (run_dir / "metrics.json").exists() or (run_dir / "model.pt").exists():
        raise FileExistsError(f"existing run in {run_dir}; use a new output directory")
    history = []
    started = time.perf_counter()
    print(json.dumps({"configuration": configuration, "model_parameters": parameters,
                      "train_examples": len(train_loader.labels),
                      "test_examples": len(test_loader.labels), "epochs": EPOCHS,
                      "device": str(device), "seed": seed}), flush=True)
    for epoch in range(1, EPOCHS + 1):
        epoch_started = time.perf_counter()
        metrics = train_epoch(model, train_loader, criterion=criterion,
                              optimizer=optimizer, batch_adapter=tuple_batch_adapter,
                              device=device, gradient_clip_norm=None)
        row = {"epoch": epoch, **metrics,
               "seconds": time.perf_counter() - epoch_started}
        history.append(row)
        print(json.dumps(row), flush=True)
        _save_json(run_dir / "training_history.json", history)
        if epoch % 5 == 0 or epoch == EPOCHS:
            temporary = run_dir / "model.pt.tmp"
            torch.save({"model_state_dict": model.state_dict(),
                        "optimizer_state_dict": optimizer.state_dict(),
                        "model_parameters": parameters, "completed_epochs": epoch,
                        "training": history, "seed": seed,
                        "data_sha256": metadata["data_sha256"]}, temporary)
            temporary.replace(run_dir / "model.pt")
    # The held-out split is evaluated once after the fixed training budget.
    test_metrics = evaluate(model, test_loader, criterion=criterion,
                            batch_adapter=tuple_batch_adapter, device=device)
    result = {"configuration": configuration, "model_parameters": parameters,
              "epochs": EPOCHS, "batch_size": BATCH_SIZE, "optimizer": "Adam",
              "learning_rate": LEARNING_RATE, "criterion": "CrossEntropyLoss",
              "gradient_clip_norm": None, "seed": seed, "device": str(device),
              "torch_version": str(torch.__version__), "prepared_data": metadata,
              "training": history, "test": test_metrics,
              "elapsed_seconds": time.perf_counter() - started}
    _save_json(run_dir / "metrics.json", result)
    print(json.dumps({"configuration": configuration, "test": test_metrics}), flush=True)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    prepare = commands.add_parser("prepare", help="prepare one shared course split/vocabulary")
    prepare.add_argument("--dataset-root", required=True)
    prepare.add_argument("--prepared-dir", required=True)
    prepare.add_argument("--seed", type=int, default=SEED)
    for name in ("train", "all"):
        command = commands.add_parser(name)
        command.add_argument("--prepared-dir", required=True)
        command.add_argument("--output-dir", required=True)
        command.add_argument("--device", default="cuda")
        if name == "train":
            command.add_argument("--configuration", choices=CONFIGURATIONS, required=True)
    args = parser.parse_args()
    if args.command == "prepare":
        result = prepare_course_data(args.dataset_root, args.prepared_dir, seed=args.seed)
        print(json.dumps(result, indent=2), flush=True)
    else:
        choices = [args.configuration] if args.command == "train" else CONFIGURATIONS
        for configuration in choices:
            train_configuration(args.prepared_dir, args.output_dir, configuration,
                                device=args.device)


if __name__ == "__main__":
    main()
