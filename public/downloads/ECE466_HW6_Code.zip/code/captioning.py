"""ECE 466 HW6, Q2: image captioning with ResNet50/GoogLeNet and LSTM/RNN.

Adapted from the verified course Image_Captioning.ipynb and supporting files,
which are based on the public reference by Benjamin Dwumah:
https://github.com/Ben74x/Image-Captioning-on-MSCoco-Dataset
Commit: 7b6f0f85d03ae0226f3ccc9723fe1179141ece6c.
The course notebook, README, model, loader and vocabulary code were read and
compared with this implementation; their SHA256 hashes are recorded below.

Main corrections: complete epochs without replacement, optional frozen CNN statistics,
deterministic test preprocessing, bounded decoding, and identical comparison images.
Synthetic tests check implementation only; they are not assignment experiment results.

Upstream MIT notice: Copyright (c) 2022 Benjamin Dwumah.
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

import argparse
import csv
import hashlib
import json
import math
import random
import time
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from torch import nn
from torch.utils.data import DataLoader, Dataset, Sampler
from torchvision import models, transforms


SOURCE_URL = "https://github.com/Ben74x/Image-Captioning-on-MSCoco-Dataset"
SOURCE_COMMIT = "7b6f0f85d03ae0226f3ccc9723fe1179141ece6c"
COURSE_SOURCE_HASHES = {
    "Image_Captioning.ipynb": "c0d5ea393f5043ca2f4a1877ca8cedf603ad8b580a7c6538b469d5e95cddc115",
    "README.md": "cc11b3ab72cac632f6b4df470e0ba0abde421ee33dff2fbb8fe67d9e1ffe261a",
    "model.py": "18017091ff559e6acbbf0f71d0ee3c5280c0773daf43204dc872c97c5423a4ff",
    "dataLoader.py": "ec8ab49a3ee52cb5ebeec6e883d9d233babb1ddf9acdb1839e3181a2e298ffd1",
    "vocabulary.py": "82f2cb5f808c24f0b8c40f24d998e15072e1210009aab8ac6fb8434e61e4017b",
}
METRIC_KIND = "token-weighted online training loss during the epoch"
VARIANTS = {
    "baseline": ("resnet50", "lstm"),
    "alternate_encoder": ("googlenet", "lstm"),
    "simple_rnn": ("resnet50", "rnn"),
}


@dataclass
class Config:
    backbone: str = "resnet50"
    cell: str = "lstm"
    embed_size: int = 512
    hidden_size: int = 512
    batch_size: int = 256  # Exact course notebook value; public upstream uses 32.
    vocab_threshold: int = 6
    epochs: int = 1  # Exact course notebook value.
    learning_rate: float = 0.001
    seed: int = 466
    num_workers: int = 0
    max_length: int = 30
    freeze_backbone_stats: bool = False  # False preserves upstream training-mode BatchNorm.
    channels_last: bool = False  # Optional CNN/image storage layout; arithmetic remains FP32.


def sha256_file(path):
    """Hash file bytes in bounded chunks; compatible with Python 3.10."""
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json_atomic(path, value):
    """Replace a complete JSON file so a live reader never sees a partial write."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def tokenize(text):
    """Use the same lowercase NLTK word tokenizer as the public notebook."""
    import nltk
    return nltk.word_tokenize(str(text).lower())


class Vocabulary:
    def __init__(self, words):
        self.words = list(words)
        if self.words[:3] != ["<start>", "<end>", "<unk>"]:
            raise ValueError("Vocabulary must begin with <start>, <end>, <unk>.")
        if len(set(self.words)) != len(self.words):
            raise ValueError("Vocabulary contains duplicate tokens.")
        self.word_to_id = {word: index for index, word in enumerate(self.words)}

    @classmethod
    def build(cls, tokenized_captions, threshold=6):
        counts = Counter(word for caption in tokenized_captions for word in caption)
        specials = ["<start>", "<end>", "<unk>"]
        return cls(specials + [word for word, count in counts.items()
                               if count >= threshold and word not in specials])

    def encode(self, tokens):
        return [self.word_to_id["<start>"]] + [
            self.word_to_id.get(word, self.word_to_id["<unk>"]) for word in tokens
        ] + [self.word_to_id["<end>"]]

    def decode(self, token_ids):
        words = []
        for index in token_ids:
            word = self.words[index]
            if word == "<end>":
                break
            if word != "<start>":
                words.append(word)
        sentence = " ".join(words)
        return sentence[:1].upper() + sentence[1:]

    def __len__(self):
        return len(self.words)


def image_transform(training):
    if training:
        operations = [transforms.Resize(256), transforms.RandomCrop(224),
                      transforms.RandomHorizontalFlip()]
    else:
        # This is transform_test defined (but accidentally unused) in upstream.
        operations = [transforms.Resize((224, 224))]
    return transforms.Compose(operations + [
        transforms.ToTensor(),
        transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225)),
    ])


class CocoCaptions(Dataset):
    """One item per caption annotation, including all captions for each image."""
    def __init__(self, images_dir, annotations_file, threshold=6, vocabulary=None):
        self.images_dir = Path(images_dir)
        with Path(annotations_file).open(encoding="utf-8") as handle:
            annotations = json.load(handle)
        self.records = annotations["annotations"]
        if not self.records:
            raise ValueError("Training annotations are empty.")
        self.image_names = {image["id"]: image["file_name"]
                            for image in annotations["images"]}
        self.annotation_ids = [record["id"] for record in self.records]
        if len(set(self.annotation_ids)) != len(self.annotation_ids):
            raise ValueError("Caption annotation IDs are not unique.")
        tokenized = [tokenize(record["caption"]) for record in self.records]
        self.vocabulary = vocabulary or Vocabulary.build(tokenized, threshold)
        self.captions = [torch.tensor(self.vocabulary.encode(tokens), dtype=torch.long)
                         for tokens in tokenized]
        self.lengths = [len(caption) for caption in self.captions]
        self.transform = image_transform(training=True)
        missing = [name for name in set(self.image_names[record["image_id"]]
                                       for record in self.records)
                   if not (self.images_dir / name).is_file()]
        if missing:
            raise FileNotFoundError(f"Missing {len(missing)} training images; first: {missing[0]}")

    def __len__(self):
        return len(self.records)

    def __getitem__(self, index):
        record = self.records[index]
        image_path = self.images_dir / self.image_names[record["image_id"]]
        with Image.open(image_path) as image:
            tensor = self.transform(image.convert("RGB"))
        return tensor, self.captions[index], record["id"]


class LengthBucketBatchSampler(Sampler):
    """Shuffle equal-length batches, visiting every caption exactly once per epoch."""
    def __init__(self, lengths, batch_size, seed=466):
        if batch_size < 1:
            raise ValueError("batch_size must be positive.")
        self.buckets = defaultdict(list)
        for index, length in enumerate(lengths):
            self.buckets[length].append(index)
        self.batch_size = batch_size
        self.seed = seed
        self.epoch = 0

    def set_epoch(self, epoch):
        self.epoch = epoch

    def __iter__(self):
        rng = random.Random(self.seed + self.epoch)
        batches = []
        for indices in self.buckets.values():
            shuffled = list(indices)
            rng.shuffle(shuffled)
            batches.extend(shuffled[start:start + self.batch_size]
                           for start in range(0, len(shuffled), self.batch_size))
        rng.shuffle(batches)
        yield from batches

    def __len__(self):
        return sum(math.ceil(len(indices) / self.batch_size)
                   for indices in self.buckets.values())


class EncoderCNN(nn.Module):
    def __init__(self, backbone="resnet50", embed_size=512, pretrained=True,
                 freeze_backbone_stats=False, channels_last=False):
        super().__init__()
        self.freeze_backbone_stats = freeze_backbone_stats
        self.channels_last = channels_last
        if backbone == "resnet50":
            weights = models.ResNet50_Weights.IMAGENET1K_V1 if pretrained else None
            self.backbone = models.resnet50(weights=weights)
        elif backbone == "googlenet":
            weights = models.GoogLeNet_Weights.IMAGENET1K_V1 if pretrained else None
            # Do not pass aux_logits=False to the pretrained builder: its weight
            # loader initially requires the auxiliary modules. Remove them after loading.
            self.backbone = models.googlenet(weights=weights, init_weights=False,
                                             transform_input=True)
            self.backbone.aux_logits = False
            self.backbone.aux1 = None
            self.backbone.aux2 = None
        else:
            raise ValueError(f"Unsupported encoder: {backbone}")
        feature_size = self.backbone.fc.in_features
        self.backbone.fc = nn.Identity()
        for parameter in self.backbone.parameters():
            parameter.requires_grad_(False)
        if channels_last:
            self.backbone.to(memory_format=torch.channels_last)
        if freeze_backbone_stats:
            self.backbone.eval()
        self.embed = nn.Linear(feature_size, embed_size)
        # Upstream declares an extra BatchNorm1d but never calls it; it is omitted.

    def train(self, mode=True):
        super().train(mode)
        if self.freeze_backbone_stats:
            self.backbone.eval()  # Optional explicit change from the public baseline.
        return self

    def forward(self, images):
        if self.channels_last:
            images = images.contiguous(memory_format=torch.channels_last)
        with torch.no_grad():
            features = self.backbone(images)
        return self.embed(features)


class DecoderRNN(nn.Module):
    def __init__(self, embed_size, hidden_size, vocab_size, cell="lstm"):
        super().__init__()
        self.word_embeddings = nn.Embedding(vocab_size, embed_size)
        if cell == "lstm":
            recurrent_layer = nn.LSTM
        elif cell == "rnn":
            recurrent_layer = nn.RNN  # Default activation is tanh.
        else:
            raise ValueError(f"Unsupported decoder: {cell}")
        self.recurrent = recurrent_layer(embed_size, hidden_size, num_layers=1,
                                         batch_first=True, dropout=0,
                                         bidirectional=False)
        self.linear = nn.Linear(hidden_size, vocab_size)

    def forward(self, features, captions):
        # Inputs: [image, <start>, word1, ...]; targets: [<start>, word1, ..., <end>].
        embeddings = self.word_embeddings(captions[:, :-1])
        inputs = torch.cat((features.unsqueeze(1), embeddings), dim=1)
        outputs, _ = self.recurrent(inputs)  # Hidden state starts at zero each batch.
        return self.linear(outputs)

    @torch.no_grad()
    def sample(self, features, end_id, max_length=30):
        if features.ndim != 2 or features.shape[0] != 1:
            raise ValueError("sample expects one image feature vector, shape (1, embed_size).")
        if max_length < 1:
            raise ValueError("max_length must be positive.")
        inputs = features.unsqueeze(1)
        hidden = None
        generated = []
        for _ in range(max_length):
            outputs, hidden = self.recurrent(inputs, hidden)
            next_id = self.linear(outputs[:, -1]).argmax(dim=-1)
            index = int(next_id.item())
            generated.append(index)
            if index == end_id:
                break
            inputs = self.word_embeddings(next_id).unsqueeze(1)
        return generated


class CaptionModel(nn.Module):
    def __init__(self, config, vocab_size, pretrained=True):
        super().__init__()
        self.encoder = EncoderCNN(config.backbone, config.embed_size, pretrained,
                                  config.freeze_backbone_stats, config.channels_last)
        self.decoder = DecoderRNN(config.embed_size, config.hidden_size, vocab_size, config.cell)

    def forward(self, images, captions):
        return self.decoder(self.encoder(images), captions)


def train_epoch(model, loader, optimizer, device, progress_path=None, epoch=1):
    """Return a token-weighted epoch mean, not the final batch's loss."""
    model.train()
    criterion = nn.CrossEntropyLoss(reduction="sum")
    total_loss = 0.0
    total_tokens = 0
    seen_ids = set()
    start_time = time.perf_counter()

    def report_progress(state, completed_batches):
        if progress_path is not None:
            online_loss = total_loss / total_tokens
            write_json_atomic(progress_path, {
                "state": state, "epoch": epoch, "total_batches": len(loader),
                "completed_batches": completed_batches, "seen_captions": len(seen_ids),
                "total_captions": len(loader.dataset), "online_loss": online_loss,
                "perplexity": math.exp(online_loss),
                "elapsed_seconds": time.perf_counter() - start_time,
            })

    for step, (images, captions, annotation_ids) in enumerate(loader, start=1):
        ids = annotation_ids.tolist()
        if len(set(ids)) != len(ids) or seen_ids.intersection(ids):
            raise RuntimeError("An annotation was repeated within this epoch.")
        seen_ids.update(ids)
        images, captions = images.to(device), captions.to(device)
        optimizer.zero_grad(set_to_none=True)
        outputs = model(images, captions)
        loss_sum = criterion(outputs.reshape(-1, outputs.size(-1)), captions.reshape(-1))
        token_count = captions.numel()
        loss = loss_sum / token_count
        if not torch.isfinite(loss):
            raise RuntimeError(f"Nonfinite loss at batch {step}.")
        loss.backward()
        optimizer.step()
        total_loss += float(loss_sum.detach().item())
        total_tokens += token_count
        if step == 1 or step % 20 == 0 or step == len(loader):
            report_progress("partial_epoch", step)
            print(f"Batch {step}/{len(loader)}: loss={loss.item():.4f}", flush=True)
    if len(seen_ids) != len(loader.dataset):
        raise RuntimeError("Epoch did not include every caption annotation.")
    report_progress("epoch_complete", step)
    mean_loss = total_loss / total_tokens
    return {"train_loss": mean_loss, "perplexity": math.exp(mean_loss),
            "caption_count": len(seen_ids), "token_count": total_tokens,
            "batch_count": len(loader), "seconds": time.perf_counter() - start_time}


def train(config, images_dir, annotations_file, output_dir, device, vocabulary_json=None):
    if config.epochs < 1:
        raise ValueError("At least one full epoch is required.")
    set_seed(config.seed)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    vocabulary = None
    if vocabulary_json is not None:
        words = json.loads(Path(vocabulary_json).read_text(encoding="utf-8"))
        if not isinstance(words, list) or any(not isinstance(word, str) for word in words):
            raise ValueError("Vocabulary JSON must be a list of strings in token-ID order.")
        vocabulary = Vocabulary(words)
    dataset = CocoCaptions(images_dir, annotations_file, config.vocab_threshold,
                           vocabulary=vocabulary)
    sampler = LengthBucketBatchSampler(dataset.lengths, config.batch_size, config.seed)
    loader = DataLoader(dataset, batch_sampler=sampler, num_workers=config.num_workers,
                        pin_memory=device.type == "cuda")
    model = CaptionModel(config, len(dataset.vocabulary), pretrained=True).to(device)
    optimizer = torch.optim.Adam((p for p in model.parameters() if p.requires_grad),
                                 lr=config.learning_rate, betas=(0.9, 0.999), eps=1e-8)
    metadata = {"config": asdict(config), "source_url": SOURCE_URL,
                "source_commit": SOURCE_COMMIT, "course_copy_verified": True,
                "course_source_hashes": dict(COURSE_SOURCE_HASHES),
                "vocabulary_size": len(dataset.vocabulary),
                "training_images": len(set(record["image_id"] for record in dataset.records)),
                "training_captions": len(dataset), "completed_epochs": 0,
                "annotations_file": str(Path(annotations_file).resolve()),
                "images_dir": str(Path(images_dir).resolve()), "epochs": []}
    metadata["annotations_sha256"] = sha256_file(annotations_file)
    metadata["vocabulary_source"] = ("provided_json" if vocabulary_json is not None
                                     else "built_from_training_annotations")
    vocabulary_source_path = Path(vocabulary_json if vocabulary_json is not None else annotations_file)
    metadata["vocabulary_source_path"] = str(vocabulary_source_path.resolve())
    metadata["vocabulary_source_sha256"] = sha256_file(vocabulary_source_path)
    metadata["metric_kind"] = METRIC_KIND
    (output_dir / "vocabulary.json").write_text(
        json.dumps(dataset.vocabulary.words, ensure_ascii=False), encoding="utf-8")
    with (output_dir / "metrics.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = None
        for epoch in range(1, config.epochs + 1):
            sampler.set_epoch(epoch - 1)
            metrics = {"epoch": epoch, **train_epoch(
                model, loader, optimizer, device,
                progress_path=output_dir / "training_progress.json", epoch=epoch)}
            if writer is None:
                writer = csv.DictWriter(handle, fieldnames=list(metrics))
                writer.writeheader()
            writer.writerow(metrics)
            handle.flush()
            metadata["epochs"].append(metrics)
            metadata["completed_epochs"] = epoch
            torch.save({"config": asdict(config), "vocabulary": dataset.vocabulary.words,
                        "model_state": model.state_dict(), "optimizer_state": optimizer.state_dict(),
                        "epoch": epoch, "metrics": metrics,
                        "training_captions": len(dataset),
                        "annotations_sha256": metadata["annotations_sha256"],
                        "metric_kind": METRIC_KIND,
                        "course_copy_verified": True,
                        "course_source_hashes": dict(COURSE_SOURCE_HASHES),
                        "vocabulary_source": metadata["vocabulary_source"],
                        "vocabulary_source_path": metadata["vocabulary_source_path"],
                        "vocabulary_source_sha256": metadata["vocabulary_source_sha256"],
                        "source_url": SOURCE_URL, "source_commit": SOURCE_COMMIT},
                       output_dir / f"caption_epoch_{epoch}.pt")
            (output_dir / "training_results.json").write_text(
                json.dumps(metadata, indent=2), encoding="utf-8")
            print(f"Epoch {epoch}: loss={metrics['train_loss']:.6f}, "
                  f"perplexity={metrics['perplexity']:.6f}", flush=True)
    return metadata


def load_checkpoint(path, device):
    checkpoint = torch.load(path, map_location="cpu", weights_only=True)
    if checkpoint["epoch"] < 1 or checkpoint["metrics"]["caption_count"] != checkpoint["training_captions"]:
        raise ValueError("Checkpoint does not record a completed full epoch.")
    if checkpoint["metrics"]["batch_count"] < 1:
        raise ValueError("Checkpoint contains no completed training batches.")
    config = Config(**checkpoint["config"])
    vocabulary = Vocabulary(checkpoint["vocabulary"])
    model = CaptionModel(config, len(vocabulary), pretrained=False)
    model.load_state_dict(checkpoint["model_state"])
    model.to(device).eval()
    model.training_metadata = {key: checkpoint[key]
                               for key in ("epoch", "training_captions", "annotations_sha256")}
    return model, vocabulary, config


@torch.inference_mode()
def get_prediction(model, image_path, vocabulary, device, max_length=30):
    """Upstream-style prediction with an explicit image, so comparisons stay aligned."""
    model.eval()
    with Image.open(image_path) as image:
        tensor = image_transform(training=False)(image.convert("RGB")).unsqueeze(0)
    features = model.encoder(tensor.to(device))
    output = model.decoder.sample(features, vocabulary.word_to_id["<end>"], max_length)
    return vocabulary.decode(output)


def compare(checkpoints, images_dir, image_info, output_dir, device, seed=466, count=4):
    if len(checkpoints) != 3:
        raise ValueError("Comparison requires all three HW6 model variants.")
    with Path(image_info).open(encoding="utf-8") as handle:
        image_records = json.load(handle)["images"]
    # Select IDs once, before loading any model; every model receives these images.
    selected = random.Random(seed).sample(sorted(image_records, key=lambda item: item["id"]), count)
    predictions = [{"image_id": record["id"], "file_name": record["file_name"],
                    "image_path": str((Path(images_dir) / record["file_name"]).resolve()),
                    "captions": {}} for record in selected]
    model_names = []
    required_names = {f"{backbone}_{cell}" for backbone, cell in VARIANTS.values()}
    reference_vocabulary = None
    reference_protocol = None
    comparison_evidence = []
    for checkpoint_path in checkpoints:
        model, vocabulary, config = load_checkpoint(checkpoint_path, device)
        label = f"{config.backbone}_{config.cell}"
        if label not in required_names or label in model_names:
            raise ValueError(f"Unexpected or duplicate HW6 model variant: {label}")
        protocol = {key: asdict(config)[key] for key in (
            "embed_size", "hidden_size", "batch_size", "vocab_threshold",
            "learning_rate", "seed", "max_length", "freeze_backbone_stats")}
        protocol.update(model.training_metadata)
        if reference_vocabulary is None:
            reference_vocabulary = vocabulary.words
            reference_protocol = protocol
        elif vocabulary.words != reference_vocabulary or protocol != reference_protocol:
            raise ValueError("Models must use the same vocabulary, data, epoch count, and training settings.")
        # Memory layout is recorded separately from the shared learning protocol.
        # It changes storage/reduction ordering, not the architecture or precision.
        comparison_evidence.append({"model": label, **protocol,
                                    "channels_last": config.channels_last,
                                    "cnn_memory_format": "channels_last" if config.channels_last else "contiguous",
                                    "precision": "float32"})
        model_names.append(label)
        for prediction in predictions:
            prediction["captions"][label] = get_prediction(
                model, prediction["image_path"], vocabulary, device, config.max_length)
        del model
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    result = {"seed": seed, "checkpoints": [str(Path(p).resolve()) for p in checkpoints],
              "comparison_protocol": comparison_evidence, "predictions": predictions}
    (output_dir / "predictions.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    import textwrap
    figure = Figure(figsize=(13, count * 3.2))
    FigureCanvasAgg(figure)
    axes = figure.subplots(count, 2, squeeze=False)
    for row, prediction in enumerate(predictions):
        with Image.open(prediction["image_path"]) as image:
            axes[row, 0].imshow(image.convert("RGB"))
        axes[row, 0].set_title(f"Image {prediction['image_id']}")
        axes[row, 0].axis("off")
        lines = []
        for label, sentence in prediction["captions"].items():
            lines.extend([label, textwrap.fill(sentence, width=65), ""])
        axes[row, 1].text(0, 1, "\n".join(lines), va="top", fontsize=10)
        axes[row, 1].axis("off")
    figure.tight_layout()
    figure.savefig(output_dir / "four_image_comparison.png", dpi=180, bbox_inches="tight")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    commands = parser.add_subparsers(dest="command", required=True)
    training = commands.add_parser("train")
    training.add_argument("--variant", choices=VARIANTS, default="baseline")
    training.add_argument("--images-dir", type=Path, required=True)
    training.add_argument("--annotations", type=Path, required=True)
    training.add_argument("--output-dir", type=Path, required=True)
    training.add_argument("--vocabulary-json", type=Path,
                          help="Existing vocabulary JSON list in token-ID order; use the supplied course mapping.")
    training.add_argument("--epochs", type=int, default=1)
    training.add_argument("--batch-size", type=int, default=256)
    training.add_argument("--num-workers", type=int, default=0)
    training.add_argument("--seed", type=int, default=466)
    training.add_argument("--download-nltk", action="store_true")
    training.add_argument("--freeze-backbone-stats", action="store_true",
                          help="Keep frozen CNN BatchNorm/dropout in eval mode; changes upstream protocol.")
    training.add_argument("--channels-last", action="store_true",
                          help="Use channels-last CNN/image memory layout; retains FP32 and CNN training mode.")
    prediction = commands.add_parser("compare")
    prediction.add_argument("--checkpoints", nargs=3, type=Path, required=True)
    prediction.add_argument("--images-dir", type=Path, required=True)
    prediction.add_argument("--image-info", type=Path, required=True)
    prediction.add_argument("--output-dir", type=Path, required=True)
    prediction.add_argument("--seed", type=int, default=466)
    args = parser.parse_args()
    device = torch.device(args.device)
    if args.command == "train":
        if args.download_nltk:
            import nltk
            nltk.download("punkt", raise_on_error=True)
            nltk.download("punkt_tab", raise_on_error=True)
        backbone, cell = VARIANTS[args.variant]
        config = Config(backbone=backbone, cell=cell, epochs=args.epochs,
                        batch_size=args.batch_size, num_workers=args.num_workers, seed=args.seed,
                        freeze_backbone_stats=args.freeze_backbone_stats,
                        channels_last=args.channels_last)
        train(config, args.images_dir, args.annotations, args.output_dir, device,
              vocabulary_json=args.vocabulary_json)
    else:
        compare(args.checkpoints, args.images_dir, args.image_info, args.output_dir,
                device, args.seed)


if __name__ == "__main__":
    main()
