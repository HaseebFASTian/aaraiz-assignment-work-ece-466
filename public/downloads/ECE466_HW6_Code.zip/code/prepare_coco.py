"""Prepare official COCO 2017 training data and four reproducible test images.

Python 3.10+, standard library only. Run on a CPU node with enough disk space
for the retained 19.34 GB training ZIP plus all extracted training images.
Downloads resume through HTTP Range requests. No training is performed here.

Example:
  python prepare_coco.py --output-dir /path/to/project/data/coco --seed 466
"""

import argparse
import errno
import hashlib
import http.client
import json
import os
from pathlib import Path, PurePosixPath
import random
import re
import shutil
import stat
import time
import urllib.error
import urllib.request
import zipfile
import zlib


SOURCE_PAGE = "https://github.com/cocodataset/cocodataset.github.io/blob/master/dataset/download.htm"
BASE_URL = "https://s3.amazonaws.com/images.cocodataset.org"
TRAIN_ARCHIVE_BYTES = 19336861798
EXPECTED_TRAIN_IMAGES = 118287
EXPECTED_TRAIN_CAPTIONS = 591753
CHUNK = 4 * 1024 * 1024


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for data in iter(lambda: handle.read(CHUNK), b""):
            digest.update(data)
    return digest.hexdigest()


def write_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def request(url, method="GET", headers=None):
    headers = {"User-Agent": "ECE466-COCO-Preparation/1.0", "Accept-Encoding": "identity",
               **(headers or {})}
    return urllib.request.urlopen(urllib.request.Request(url, headers=headers, method=method),
                                  timeout=120)


def download(url, destination, expected_size=None, retries=8):
    """Resume only a validated HTTP byte range; restart if the server ignores Range."""
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    partial = destination.with_name(destination.name + ".part")
    sidecar = destination.with_name(destination.name + ".http.json")
    metadata = None
    for attempt in range(retries):
        try:
            with request(url, method="HEAD") as response:
                total = int(response.headers["Content-Length"])
                etag = response.headers.get("ETag")
                metadata = {"url": url, "content_length": total, "etag": etag,
                            "last_modified": response.headers.get("Last-Modified")}
            if expected_size is not None and total != expected_size:
                raise ValueError(f"Unexpected size for {url}: {total}, expected {expected_size}")
            previous = json.loads(sidecar.read_text(encoding="utf-8")) if sidecar.exists() else None
            if previous and (previous["url"] != url or previous["content_length"] != total
                             or (previous.get("etag") and etag and previous["etag"] != etag)):
                raise ValueError(f"Remote content changed; inspect existing download: {destination}")
            write_json(sidecar, metadata)
            if destination.exists():
                if destination.stat().st_size == total:
                    print(f"Already downloaded: {destination.name} ({total} bytes)", flush=True)
                    return metadata
                if destination.stat().st_size > total or partial.exists():
                    raise ValueError(f"Conflicting existing download: {destination}")
                os.replace(destination, partial)
            offset = partial.stat().st_size if partial.exists() else 0
            if offset > total:
                raise ValueError(f"Partial file exceeds remote size: {partial}")
            if offset == total:
                os.replace(partial, destination)
                return metadata
            if shutil.disk_usage(destination.parent).free < total - offset + 64 * 1024 * 1024:
                raise OSError(errno.ENOSPC, f"Insufficient space for {destination.name}")
            headers = {"Range": f"bytes={offset}-"} if offset else {}
            if offset and etag:
                headers["If-Range"] = etag
            with request(url, headers=headers) as response:
                status = response.getcode()
                if status == 206:
                    content_range = response.headers.get("Content-Range", "")
                    match = re.fullmatch(r"bytes (\d+)-(\d+)/(\d+)", content_range)
                    if not match or int(match[1]) != offset or int(match[3]) != total:
                        raise ValueError(f"Invalid resume response: {content_range}")
                    mode = "ab" if offset else "wb"
                elif status == 200:
                    # A server may ignore Range or fail If-Range. Never append a full response.
                    offset = 0
                    mode = "wb"
                else:
                    raise ValueError(f"Unexpected HTTP status {status}: {url}")
                print(f"Downloading {destination.name}: starting at {offset}/{total} bytes", flush=True)
                last_report = time.monotonic()
                with partial.open(mode) as output:
                    while True:
                        block = response.read(CHUNK)
                        if not block:
                            break
                        output.write(block)
                        offset += len(block)
                        if offset > total:
                            raise ValueError(f"Response exceeds declared length: {url}")
                        if time.monotonic() - last_report >= 15:
                            print(f"  {destination.name}: {offset}/{total} ({100 * offset / total:.1f}%)",
                                  flush=True)
                            last_report = time.monotonic()
            if partial.stat().st_size != total:
                raise OSError(f"Incomplete download: {partial.stat().st_size}/{total} bytes")
            os.replace(partial, destination)
            print(f"Download complete: {destination.name}", flush=True)
            return metadata
        except (urllib.error.URLError, TimeoutError, ConnectionError,
                http.client.IncompleteRead, OSError) as error:
            if isinstance(error, urllib.error.HTTPError) and error.code not in (408, 429, 500, 502, 503, 504):
                raise
            if getattr(error, "errno", None) in (errno.ENOSPC, errno.EACCES, errno.EPERM):
                raise
            if attempt + 1 == retries:
                raise
            delay = min(60, 2 ** (attempt + 1))
            print(f"Download interrupted ({error}); resume attempt {attempt + 2} in {delay}s", flush=True)
            time.sleep(delay)
    raise RuntimeError(f"Could not download {url}")


def safe_member(info):
    path = PurePosixPath(info.filename)
    if path.is_absolute() or ".." in path.parts or "\\" in info.filename or ":" in info.filename:
        raise ValueError(f"Unsafe ZIP path: {info.filename}")
    if stat.S_ISLNK(info.external_attr >> 16) or info.flag_bits & 1:
        raise ValueError(f"Unsupported link/encrypted ZIP member: {info.filename}")


def file_checks(path):
    digest = hashlib.sha256()
    crc = 0
    count = 0
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(CHUNK), b""):
            digest.update(block)
            crc = zlib.crc32(block, crc)
            count += len(block)
    return {"bytes": count, "sha256": digest.hexdigest(), "crc32": f"{crc & 0xffffffff:08x}"}


def extract_member(archive, info, destination, output_root):
    """Validate member CRC before replacing a destination; safely reuse verified files."""
    safe_member(info)
    destination = Path(destination)
    if not destination.resolve().is_relative_to(Path(output_root).resolve()):
        raise ValueError(f"Extraction leaves output directory: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    expected_crc = f"{info.CRC:08x}"
    if destination.is_file() and destination.stat().st_size == info.file_size:
        checks = file_checks(destination)
        if checks["crc32"] == expected_crc:
            return checks
    temporary = destination.with_name(destination.name + ".extracting")
    digest = hashlib.sha256()
    crc = 0
    count = 0
    with archive.open(info) as source, temporary.open("wb") as output:
        while True:
            block = source.read(CHUNK)  # ZipExtFile also validates CRC at EOF.
            if not block:
                break
            output.write(block)
            digest.update(block)
            crc = zlib.crc32(block, crc)
            count += len(block)
    if count != info.file_size or (crc & 0xffffffff) != info.CRC:
        raise ValueError(f"ZIP integrity check failed: {info.filename}")
    os.replace(temporary, destination)
    return {"bytes": count, "sha256": digest.hexdigest(), "crc32": f"{crc & 0xffffffff:08x}"}


def extract_json(archive_path, member_name, output_root):
    with zipfile.ZipFile(archive_path) as archive:
        matches = [info for info in archive.infolist() if info.filename == member_name]
        if len(matches) != 1:
            raise ValueError(f"Expected one {member_name} in {archive_path}")
        destination = output_root / "annotations" / PurePosixPath(member_name).name
        checks = extract_member(archive, matches[0], destination, output_root)
    with destination.open(encoding="utf-8") as handle:
        data = json.load(handle)
    return data, {"path": str(destination.relative_to(output_root)), **checks}


def extract_training_images(archive_path, output_root, expected_names):
    inventory = output_root / "work" / "train_image_hashes.jsonl"
    temporary_inventory = inventory.with_name(inventory.name + ".tmp")
    inventory_digest = hashlib.sha256()
    total_bytes = 0
    with zipfile.ZipFile(archive_path) as archive:
        members = {}
        for info in archive.infolist():
            safe_member(info)
            if info.is_dir():
                continue
            path = PurePosixPath(info.filename)
            if len(path.parts) != 2 or path.parts[0] != "train2017" or not re.fullmatch(r"\d{12}\.jpg", path.name):
                raise ValueError(f"Unexpected training archive member: {info.filename}")
            if path.name in members:
                raise ValueError(f"Duplicate ZIP member: {info.filename}")
            members[path.name] = info
        if set(members) != expected_names:
            raise ValueError("Training ZIP names do not exactly match the official annotation image list.")
        missing_bytes = sum(info.file_size for name, info in members.items()
                            if not (output_root / "images" / "train2017" / name).is_file())
        if shutil.disk_usage(output_root).free < missing_bytes + 128 * 1024 * 1024:
            raise OSError(errno.ENOSPC, "Insufficient free space for extracted training images.")
        with temporary_inventory.open("wb", buffering=1024 * 1024) as record_file:
            for index, name in enumerate(sorted(members), start=1):
                destination = output_root / "images" / "train2017" / name
                checks = extract_member(archive, members[name], destination, output_root)
                total_bytes += checks["bytes"]
                record = {"path": destination.relative_to(output_root).as_posix(), **checks}
                line = (json.dumps(record, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")
                record_file.write(line)
                inventory_digest.update(line)
                if index % 1000 == 0 or index == len(members):
                    record_file.flush()
                    print(f"CRC-verified training images: {index}/{len(members)}", flush=True)
    os.replace(temporary_inventory, inventory)
    return {"count": len(members), "bytes": total_bytes,
            "inventory_path": inventory.relative_to(output_root).as_posix(),
            "inventory_sha256": inventory_digest.hexdigest(),
            "inventory_format": "Sorted JSONL: relative path, bytes, SHA256 and CRC32 for every training JPEG"}


def prepare(output_dir, seed=466):
    output_root = Path(output_dir).expanduser().resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    downloads = output_root / "work" / "downloads"
    downloads.mkdir(parents=True, exist_ok=True)
    write_json(output_root / "preparation_manifest.json", {
        "status": "in_progress", "source_page": SOURCE_PAGE,
        "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "output_dir": str(output_root), "selection_seed": seed,
    })
    definitions = [
        ("annotations_trainval2017.zip", "annotations", None),
        ("image_info_test2017.zip", "annotations", None),
        ("train2017.zip", "zips", TRAIN_ARCHIVE_BYTES),
    ]
    archive_metadata = {}
    # Download annotations first so invalid data/counts fail before the 19.34 GB archive.
    for name, category, size in definitions[:2]:
        archive_metadata[name] = download(f"{BASE_URL}/{category}/{name}", downloads / name, size)
    training, training_file = extract_json(downloads / "annotations_trainval2017.zip",
                                          "annotations/captions_train2017.json", output_root)
    test_info, test_file = extract_json(downloads / "image_info_test2017.zip",
                                      "annotations/image_info_test2017.json", output_root)
    images, captions = training["images"], training["annotations"]
    if len(images) != EXPECTED_TRAIN_IMAGES or len(captions) != EXPECTED_TRAIN_CAPTIONS:
        raise ValueError(f"Wrong official training counts: {len(images)} images, {len(captions)} captions")
    image_ids = {item["id"] for item in images}
    expected_names = {item["file_name"] for item in images}
    if len(image_ids) != len(images) or len(expected_names) != len(images):
        raise ValueError("Training image IDs/filenames are not unique.")
    if len({item["id"] for item in captions}) != len(captions):
        raise ValueError("Caption IDs are not unique.")
    if any(item["image_id"] not in image_ids for item in captions):
        raise ValueError("A caption refers to an unknown image.")
    if any(not re.fullmatch(r"\d{12}\.jpg", name) for name in expected_names):
        raise ValueError("Unexpected training image filename.")
    test_images = test_info["images"]
    if len({item["id"] for item in test_images}) != len(test_images) or len(test_images) < 4:
        raise ValueError("Invalid test image list.")
    selected = random.Random(seed).sample(sorted(test_images, key=lambda item: item["id"]), 4)
    selected_records = []
    for item in selected:
        name = item["file_name"]
        if not re.fullmatch(r"\d{12}\.jpg", name):
            raise ValueError(f"Unexpected test filename: {name}")
        path = output_root / "images" / "test2017" / name
        http_info = download(f"{BASE_URL}/test2017/{name}", path)
        with path.open("rb") as handle:
            if handle.read(3) != b"\xff\xd8\xff":
                raise ValueError(f"Downloaded test image is not a JPEG: {name}")
        selected_records.append({"image_id": item["id"], "file_name": name,
                                 "path": path.relative_to(output_root).as_posix(),
                                 "sha256": sha256_file(path), **http_info})
    name, category, size = definitions[2]
    archive_metadata[name] = download(f"{BASE_URL}/{category}/{name}", downloads / name, size)
    extracted = extract_training_images(downloads / name, output_root, expected_names)
    for name in archive_metadata:
        print(f"Hashing archive: {name}", flush=True)
        archive_metadata[name].update({"path": (downloads / name).relative_to(output_root).as_posix(),
                                       "sha256": sha256_file(downloads / name)})
    manifest = {"status": "complete", "source_page": SOURCE_PAGE,
                "prepared_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "output_dir": str(output_root), "train_image_count": len(images),
                "train_caption_count": len(captions), "test_metadata_image_count": len(test_images),
                "test_images_downloaded": 4, "selection_seed": seed,
                "selection_rule": "random.Random(seed).sample(sorted(images,key=lambda x:x['id']),4)",
                "annotation_files": [training_file, test_file],
                "training_images": extracted, "selected_test_images": selected_records,
                "archives": archive_metadata,
                "validation": "Required extracted ZIP entries checked against CRC32 and size; SHA256 recorded. "
                              "JPEG test downloads checked for HTTP length and JPEG signature; "
                              "their SHA256 hashes are recorded. Full test image metadata is retained."}
    write_json(output_root / "preparation_manifest.json", manifest)
    print(json.dumps({"status": "complete", "train_images": len(images),
                      "train_captions": len(captions),
                      "test_image_ids": [item["id"] for item in selected],
                      "manifest": str(output_root / "preparation_manifest.json")}), flush=True)
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--seed", type=int, default=466)
    args = parser.parse_args()
    prepare(args.output_dir, args.seed)


if __name__ == "__main__":
    main()
